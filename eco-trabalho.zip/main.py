from flask import Flask, request

app = Flask(__name__)

# Rota inicial (página de login)
@app.route('/')
def home():
    return '''
    <h1>Bem-vindo ao EcoTrabalho PME</h1>
    <form action="/login" method="POST">
        E-mail: <input type="email" name="email"><br>
        Senha: <input type="password" name="senha"><br>
        <button type="submit">Entrar</button>
    </form>
    <a href="/register">Criar Conta</a>
    <a href="/search">Buscar Vagas</a>
    <a href="/profile">Meu Perfil</a>
    '''

# Rota para login
@app.route('/login', methods=['POST'])
def login():
    email = request.form['email']
    senha = request.form['senha']
    return f'Você entrou com o e-mail: {email}'

# Rota para criar conta
@app.route('/register')
def register():
    return '''
    <h1>Criação de Conta</h1>
    <form action="/create_account" method="POST">
        Nome: <input type="text" name="nome"><br>
        E-mail: <input type="email" name="email"><br>
        Senha: <input type="password" name="senha"><br>
        <button type="submit">Registrar</button>
    </form>
    '''

# Rota para salvar nova conta
@app.route('/create_account', methods=['POST'])
def create_account():
    nome = request.form['nome']
    email = request.form['email']
    senha = request.form['senha']
    return f'Conta criada para {nome} com o e-mail {email}'

# Rota para buscar vagas
@app.route('/search')
def search():
    return '''
    <h1>Buscar Vagas</h1>
    <form action="/search_results" method="POST">
        Palavra-chave: <input type="text" name="keyword"><br>
        Localização: <input type="text" name="location"><br>
        <button type="submit">Buscar</button>
    </form>
    '''

# Rota para exibir resultados de busca
@app.route('/search_results', methods=['POST'])
def search_results():
    keyword = request.form['keyword']
    location = request.form['location']
    return f'Buscando vagas com a palavra-chave: {keyword} e localização: {location}'

# Rota para exibir e atualizar perfil
@app.route('/profile')
def profile():
    return '''
    <h1>Meu Perfil</h1>
    <form action="/update_profile" method="POST">
        Nome: <input type="text" name="nome"><br>
        E-mail: <input type="email" name="email"><br>
        Telefone: <input type="text" name="telefone"><br>
        <button type="submit">Atualizar Perfil</button>
    </form>
    '''

@app.route('/update_profile', methods=['POST'])
def update_profile():
    nome = request.form['nome']
    email = request.form['email']
    telefone = request.form['telefone']
    return f'Perfil atualizado: Nome={nome}, E-mail={email}, Telefone={telefone}'

# Iniciar o app Flask
if __name__ == "__main__":
    app.run(host='0.0.0.0', port=8080)


